# 🐾 Patinhas Pet Shop — Website Estático

Trabalho desenvolvido com HTML e CSS puro para a disciplina de Desenvolvimento Web.

---

## 📁 Estrutura do Projeto

```
petshop/
├── index.html          ← Página principal (Home)
├── servicos.html       ← Página de Serviços
├── contato.html        ← Página de Contato
├── css/
│   └── style.css       ← Arquivo CSS externo único
├── img/
│   ├── hero-pet.jpg         ← Foto do banner principal
│   ├── pet-poodle.jpg       ← Foto do Poodle
│   ├── pet-gato.jpg         ← Foto do Gato Persa
│   ├── pet-golden.jpg       ← Foto do Golden Retriever
│   ├── pet-coelho.jpg       ← Foto do Coelho
│   └── mapa-localizacao.jpg ← Imagem do mapa
└── README.md
```

---

## 📄 Páginas

| Arquivo         | Página         | Conteúdo                                              |
|----------------|----------------|-------------------------------------------------------|
| index.html      | Início         | Hero, serviços resumidos, números, pets, diferenciais |
| servicos.html   | Serviços       | Cards detalhados, tabela de preços, raças atendidas   |
| contato.html    | Contato        | Formulário, informações, horários, FAQ               |

---

## ✅ Requisitos Atendidos

- [x] Desenvolvido apenas com HTML e CSS
- [x] 3 páginas interligadas com menu de navegação
- [x] CSS externo (css/style.css)
- [x] Semântica HTML5: header, nav, main, section, article, footer
- [x] Títulos e subtítulos (h1 a h4)
- [x] Parágrafos e textos organizados
- [x] Listas (ul, li)
- [x] Links internos e externos
- [x] Imagens (com placeholder para substituição)
- [x] Formulário completo com inputs, selects, textarea e checkbox
- [x] Tabela (tabela de preços e horários de funcionamento)
- [x] Identidade visual coerente (verde, laranja, tipografia Fredoka One + Nunito)
- [x] Responsividade com media queries para mobile e tablet
- [x] Sem frameworks ou construtores prontos

---

## 🖼️ Como Adicionar Imagens

Os placeholders nos arquivos HTML indicam onde as imagens devem ser inseridas.
Substitua os blocos `<div class="img-placeholder">` por tags `<img>`:

```html
<!-- Antes (placeholder) -->
<div class="img-placeholder" style="height:320px;">
  <span class="emoji">🐕</span>
  <span>hero-pet.jpg</span>
</div>

<!-- Depois (imagem real) -->
<img src="img/hero-pet.jpg" alt="Pet feliz no Patinhas Pet Shop" />
```

---

## 🚀 Como Abrir no IntelliJ IDEA

1. Abra o IntelliJ IDEA
2. Vá em **File > Open** e selecione a pasta `petshop`
3. Clique com o botão direito em `index.html`
4. Escolha **Open In > Browser** ou use o ícone de browser no canto superior direito
5. O site abrirá no navegador padrão

---

## 🎨 Paleta de Cores

| Variável CSS          | Cor       | Uso                    |
|----------------------|-----------|------------------------|
| --verde-principal    | #2d8f4e   | Cor primária, botões   |
| --verde-claro        | #4caf72   | Hover, destaques       |
| --verde-fundo        | #e8f5ec   | Fundos suaves          |
| --laranja            | #f97316   | Acento e destaques     |
| --amarelo            | #fbbf24   | Números, destaques     |

---

## 📱 Responsividade

- **Desktop** (>768px): Layout completo com grid de múltiplas colunas
- **Tablet** (≤768px): Colunas reduzidas, formulário em coluna única
- **Mobile** (≤480px): Layout totalmente vertical, fontes ajustadas

---

*Tema: Pet Shop — Patinhas Pet Shop*  
*Tecnologias: HTML5 + CSS3*
